this is a very new application, and this was made in VS (visual studio 2022) so this might be unstable and have some problems,
For additional help/if you have a update idea/report problems, contact GTNOCAD#9611 on discord.


